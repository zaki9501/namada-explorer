`Namada Explorer` is a disposable light explorer for Cosmos-based blockchains. It is designed to connect to any Cosmos SDK chain using only WebSocket RPC. This can be useful when developing Cosmos-based chains and exploring blockchain data through a UI.

## Features

- The ability to connect to any Cosmos-based RPC
- A dashboard to easily monitor chain activity
- The ability to subscribe to the latest blocks and transactions
- A search function that allows you to quickly find blocks, transactions, and accounts
- A list of active validators
- A list of proposals
- Blockchain parameters