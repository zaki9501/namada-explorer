export const components = {
  Heading: {
    baseStyle: {},
  },
}
